#include <zmq.hpp>

int main(int argc, char **argv)
{
    zmq::context_t context;
    return 0;
}
